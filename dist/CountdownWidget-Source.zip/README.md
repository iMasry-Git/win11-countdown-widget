﻿# ⏱️ Windows 11 Desktop Countdown Widget

A lightweight, portable, native Windows 11 desktop countdown widget designed with modern **Fluent Design** aesthetics.

It displays a live countdown directly on your Windows desktop showing **how many days are left** until your target event, along with the event name, date subtitle, progress bar, and ticking hours/minutes/seconds.

---

## ✨ Features

- **Windows 11 Fluent UI**: Frosted translucent dark/light acrylic background with rounded corners and subtle drop shadows.
- **2-Input Setup**: Effortlessly enter your **Event Name** and **Target Date** (with optional time picker).
- **Desktop Widget Experience**:
  - **Draggable**: Click and drag anywhere on the card to place it anywhere on your screens.
  - **Remembers Position**: Automatically saves its X/Y desktop position across restarts.
  - **Layer Placement Modes**:
    - **Float on Top** (Always visible over open windows)
    - **Pin to Desktop** (Sits quietly on your wallpaper behind your windows)
    - **Normal Window**
  - **Lock Position**: Lock the widget to prevent accidental dragging.
- **6 Fluent Color Themes**:
  - 🌌 *Dark Slate (Windows 11 Dark)*
  - 🌊 *Midnight Blue*
  - 🌿 *Emerald Mint*
  - 🌅 *Sunset Coral*
  - 🔮 *Neon Purple*
  - ❄️ *Light Mica*
- **Live Progress & Ticking**:
  - Displays large prominent days countdown (`45 DAYS LEFT` or `🎉 TODAY!`).
  - Journey progress bar showing percentage of time passed.
  - Live ticking timer (`⏱️ 45d 12h 34m 18s`).
- **System Tray Integration**:
  - Notification icon in the taskbar tray displaying the days remaining on hover.
  - Quick menu to edit event, show widget, or exit.
- **Windows Startup**: Optional toggle to start automatically on Windows logon.
- **Zero External Dependencies**: Built with native .NET WPF (no Python, Node.js, or heavyweight runtimes required).

---

## 🚀 How to Run

### Option 1: Quick Launch
Double-click `launch.bat` or run:
```powershell
.\bin\CountdownWidget.exe
```

### Option 2: Rebuilding from Source
If you make any changes to the C# source code, simply run:
```powershell
.\build.ps1
```

---

## 🖱️ Controls & Shortcuts

| Action | How to Trigger |
| :--- | :--- |
| **Move Widget** | Click and drag anywhere on the widget card |
| **Edit Event & Date** | Double-click the widget OR click the ⚙️ icon OR right-click > *Edit Event & Date* |
| **Lock / Unlock Dragging** | Click the 🔓/🔒 icon OR right-click > *Lock Position* |
| **Change Color Theme** | Right-click > *Color Theme* > Choose your favorite theme |
| **Pin to Wallpaper / Always on Top** | Right-click > *Window Placement* > Select mode |
| **Toggle Live Timer** | Right-click > *Show Live Ticking Time* |
| **Run on Windows Startup** | Right-click > *Start with Windows* |
| **Close / Exit** | Click ✕ (minimizes to tray) or right-click > *Exit Widget* |

---

## ⚙️ Configuration File

Your settings are automatically saved in:
```
%APPDATA%\CountdownWidget\config.json
```
